<?php
// Asegurarse de que la sesión esté iniciada.
// Esto evita el 'Notice' si la sesión ya está activa.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/../cfg/config.php"; // cargamos la clase BaseConexion

class LoginController extends BaseConexion
{
    private $db;

    public function __construct()
    {
        // crear conexión usando el método de la clase padre
        // NOTA: Asumo que la clase BaseConexion tiene el método conectar()
        $this->db = $this->conectar();
    }

    public function autenticar($correo, $contrasena)
    {
        try {
            $sql = "SELECT u.idUsuario, u.pNombre, u.aPaterno, u.correo, u.contrasena, 
                        p.descPerfil
                    FROM t_usuario u
                    LEFT JOIN t_perfil p ON u.perfil_id = p.idPerfil
                    WHERE u.correo = :correo";

            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(":correo", $correo, PDO::PARAM_STR);
            $stmt->execute();

            if ($stmt->rowCount() === 1) {
                $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

                if (password_verify($contrasena, $usuario["contrasena"])) {
                    // ÉXITO
                    $_SESSION["idUsuario"] = $usuario["idUsuario"];
                    $_SESSION["pNombre"] = $usuario["pNombre"];
                    $_SESSION["aPaterno"] = $usuario["aPaterno"];
                    $_SESSION["correo"] = $usuario["correo"];
                    $_SESSION["descPerfil"] = $usuario["descPerfil"] ?? "Sin perfil";

                    // Redirigir al menú
                    header("Location: /corevota/views/pages/menu.php");
                    exit;
                } else {
                    // FALLO: Contraseña incorrecta
                    $this->redirigirConError("Contraseña incorrecta. Inténtelo de nuevo.");
                }
            } else {
                // FALLO: Usuario no encontrado
                $this->redirigirConError("Usuario no encontrado.");
            }
        } catch (PDOException $e) {
            // Error de conexión a la BD o consulta
            $this->redirigirConError("Error de autenticación. Intente más tarde.");
        }
    }

    /**
     * Guarda el mensaje de error en sesión y redirige al login.
     * @param string $message Mensaje de error a mostrar.
     */
    private function redirigirConError($message)
    {
        // Guardar el mensaje en la sesión (que será leído por login.php)
        $_SESSION["error_message"] = $message;

        // Redirigir de vuelta a la página de login
        // NOTA: Asumo que tu login está en la raíz de /corevota/ o en /corevota/login.php
        header("Location: /corevota/views/pages/login.php");
        exit;
    }
}

// Ejecutar el login cuando venga desde el formulario
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $correo = trim($_POST["correo"]);
    $contrasena = trim($_POST["contrasena"]);

    $login = new LoginController();
    $login->autenticar($correo, $contrasena);
}
?>
